# todo-list
One of every developer's first project

Can be viewed on : www.i-teo.com/todo-list

Featured as top solution on Andrei Neagoie's The Complete Web Developer in 2022: Zero to Mastery Udemy course :
https://www.udemy.com/course/the-complete-web-developer-zero-to-mastery/learn/lecture/10562216#overview

v 1.1.0
- Deployed on i-teo.com website using cPanel's Git Version Control

v 1.0.1
- Added an ugly style.css
- Added handleUlClick function for extra flex 

v 1.0.0 
- Modified README.md file
- Removed unnecessarily variables
